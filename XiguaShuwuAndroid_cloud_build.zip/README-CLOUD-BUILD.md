# 西瓜书屋 Android WebView 项目（云端编译）

## 自动编译 APK
1. 将本项目上传到 GitHub 仓库（建议仓库名 XiguaShuwuAndroid）。
2. 打开仓库的 Actions，选择 **Build Android APK** 工作流并点击 **Run workflow**。
3. 编译完成后进入该次运行页面底部的 Artifacts，下载 `XiguaShuwu-debug-apk`。
4. 解压得到 `app-debug.apk`，传到 Android 手机安装。

此工程为网页 WebView 壳，打开 https://www.xiguashuwu.xyz/pingguo.html；并非网站原生客户端。
